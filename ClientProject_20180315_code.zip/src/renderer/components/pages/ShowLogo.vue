<style scoped>

.image-left {
    width: 100%;
    height: 100%;
}

.demo-spin-icon-load {
    animation: ani-demo-spin 1s linear infinite;
}

</style>

<template>

<Row>
    <Col span="15" style="margin:50px;">
        <img src="../../assets/500.svg" class="image-left">
    </Col>
    <Col span="9">col-12</Col>
</Row>

</template>

<script>

export default {

}

</script>
